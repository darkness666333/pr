/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package szakdolgozat;

import java.util.Timer;
import java.util.TimerTask;
import javax.swing.JOptionPane;
/**
 *
 * @author Merci
 */
public class Idözitö {
    int SeccondsPassed = 100;
    Timer mytimer = new Timer();
    TimerTask task = new TimerTask() {
        @Override
        public void run() {
            SeccondsPassed--;
            if(SeccondsPassed == 0){
                JOptionPane.showMessageDialog(null, "Öntözd meg a növényt!");
            }
        }
    };
    public void start(){
        mytimer.scheduleAtFixedRate(task, 100, 100);
    }
    public static void main(String[] args){
        Idözitö IdöProject = new Idözitö();
        IdöProject.start();
        
    }
}
